/*
 * test_fixed_point_optimization_initialize.h
 *
 * Code generation for function 'test_fixed_point_optimization_initialize'
 *
 * C source code generated on: Mon Jan 28 22:05:34 2013
 *
 */

#ifndef __TEST_FIXED_POINT_OPTIMIZATION_INITIALIZE_H__
#define __TEST_FIXED_POINT_OPTIMIZATION_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "test_fixed_point_optimization_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void test_fixed_point_optimization_initialize(void);
#endif
/* End of code generation (test_fixed_point_optimization_initialize.h) */
