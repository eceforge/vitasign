/*
 * test_fixed_point_optimization_initialize.c
 *
 * Code generation for function 'test_fixed_point_optimization_initialize'
 *
 * C source code generated on: Mon Jan 28 22:05:34 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "test_fixed_point_optimization.h"
#include "test_fixed_point_optimization_initialize.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void test_fixed_point_optimization_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/* End of code generation (test_fixed_point_optimization_initialize.c) */
