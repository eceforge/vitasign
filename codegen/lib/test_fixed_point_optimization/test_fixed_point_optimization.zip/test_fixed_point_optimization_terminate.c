/*
 * test_fixed_point_optimization_terminate.c
 *
 * Code generation for function 'test_fixed_point_optimization_terminate'
 *
 * C source code generated on: Mon Jan 28 22:05:34 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "test_fixed_point_optimization.h"
#include "test_fixed_point_optimization_terminate.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void test_fixed_point_optimization_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (test_fixed_point_optimization_terminate.c) */
