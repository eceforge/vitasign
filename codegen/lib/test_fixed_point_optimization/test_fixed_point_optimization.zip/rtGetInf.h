/*
 * rtGetInf.h
 *
 * Code generation for function 'test_fixed_point_optimization'
 *
 * C source code generated on: Mon Jan 28 22:05:34 2013
 *
 */

#ifndef __RTGETINF_H__
#define __RTGETINF_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetInf(void);
extern real32_T rtGetInfF(void);
extern real_T rtGetMinusInf(void);
extern real32_T rtGetMinusInfF(void);

#endif
/* End of code generation (rtGetInf.h) */
