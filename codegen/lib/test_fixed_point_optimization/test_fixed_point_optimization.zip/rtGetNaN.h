/*
 * rtGetNaN.h
 *
 * Code generation for function 'test_fixed_point_optimization'
 *
 * C source code generated on: Mon Jan 28 22:05:34 2013
 *
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif
/* End of code generation (rtGetNaN.h) */
