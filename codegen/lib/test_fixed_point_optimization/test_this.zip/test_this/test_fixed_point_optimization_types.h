/*
 * test_fixed_point_optimization_types.h
 *
 * Code generation for function 'test_fixed_point_optimization'
 *
 * C source code generated on: Tue Jan 29 21:54:33 2013
 *
 */

#ifndef __TEST_FIXED_POINT_OPTIMIZATION_TYPES_H__
#define __TEST_FIXED_POINT_OPTIMIZATION_TYPES_H__

/* Type Definitions */

#endif
/* End of code generation (test_fixed_point_optimization_types.h) */
