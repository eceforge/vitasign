/*
 * test_fixed_point_optimization_terminate.h
 *
 * Code generation for function 'test_fixed_point_optimization_terminate'
 *
 * C source code generated on: Tue Jan 29 21:54:33 2013
 *
 */

#ifndef __TEST_FIXED_POINT_OPTIMIZATION_TERMINATE_H__
#define __TEST_FIXED_POINT_OPTIMIZATION_TERMINATE_H__
/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "test_fixed_point_optimization_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void test_fixed_point_optimization_terminate(void);
#endif
/* End of code generation (test_fixed_point_optimization_terminate.h) */
