/*
 * test_fixed_point_optimization.h
 *
 * Code generation for function 'test_fixed_point_optimization'
 *
 * C source code generated on: Tue Jan 29 21:54:33 2013
 *
 */

#ifndef __TEST_FIXED_POINT_OPTIMIZATION_H__
#define __TEST_FIXED_POINT_OPTIMIZATION_H__
/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "test_fixed_point_optimization_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern int32_T test_fixed_point_optimization(int32_T num1, int32_T num2);
#endif
/* End of code generation (test_fixed_point_optimization.h) */
