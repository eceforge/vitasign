/*
 * testcport_terminate.c
 *
 * Code generation for function 'testcport_terminate'
 *
 * C source code generated on: Mon Jan 14 11:04:20 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "testcport.h"
#include "testcport_terminate.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void testcport_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (testcport_terminate.c) */
