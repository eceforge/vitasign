/*
 * testcport_initialize.h
 *
 * Code generation for function 'testcport_initialize'
 *
 * C source code generated on: Mon Jan 14 11:04:20 2013
 *
 */

#ifndef __TESTCPORT_INITIALIZE_H__
#define __TESTCPORT_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rtwtypes.h"
#include "testcport_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void testcport_initialize(void);
#endif
/* End of code generation (testcport_initialize.h) */
